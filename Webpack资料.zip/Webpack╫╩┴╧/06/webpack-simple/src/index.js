import a from "./a.js";
import b from "./b.js";
console.log(a + "hello,webpack-bundle!");
