import c from "./c.js";
export default "haha" + c;
