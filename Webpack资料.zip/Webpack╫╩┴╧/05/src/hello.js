export default "Hello, Webpack";
