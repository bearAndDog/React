//模块化开发 当前流行的单页面入口应用 spa
//引入模块 形成依赖
// import vue from "vue";

// import { add } from "./other.js"; //es module

// import css from "./index.css";
import "./index.css";
import "./index.less";
console.log("xiix");

// console.log("hello webpack!");

//webpack的默认配置
// 1.webpack执行构建会找 webpack.config.js这个配置文件，如果没有找到，走默认配置！
