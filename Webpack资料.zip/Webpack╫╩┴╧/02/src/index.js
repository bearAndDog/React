import css from "./css/index.less";
// import pic from "./images/logo.png";
// console.log("css");

// let ele = `<div class=${css.ele}>css module</div>`;

// var img = new Image();
//图片的路径 pic
// img.src = pic;
// var root = document.getElementById("root");
// root.append(img);

// document.write(ele);
// console.log(css, css.toString());
